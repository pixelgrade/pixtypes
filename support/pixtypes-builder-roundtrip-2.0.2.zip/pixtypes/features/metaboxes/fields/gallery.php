<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Wordpress gallery procesing
 */
global $post;

// include our gallery scripts only when we need them
wp_enqueue_media();
wp_enqueue_script( 'pixgallery' );
// ensure the wordpress modal scripts even if an editor is not present
wp_enqueue_script( 'jquery-ui-dialog', false, array( 'jquery' ), '1.0.0', true );
wp_localize_script( 'pixgallery', 'locals', array(
	'ajax_url'      => admin_url( 'admin-ajax.php' ),
	'nonce'         => wp_create_nonce( 'pixtypes_gallery_preview' ),
	'pixtypes_l18n' => array(
		'confirmClearGallery' => esc_html__( 'Are you sure you want to clear this gallery?', 'pixtypes' ),
		'alertGalleryIsEmpty' => esc_html__( 'This gallery is already empty!', 'pixtypes' )
	)
) ); ?>
<div id="pixgallery" class="pixgallery_field hidden">
	<ul></ul>
	<a class="open_pixgallery" href="#">
		<input type="hidden" name="<?php echo esc_attr( $field['id'] ); ?>" id="pixgalleries" value="<?php echo esc_attr( '' !== $meta ? $meta : $field['std'] ); ?>"/>
		<div><i class="icon dashicons dashicons-images-alt2"></i>
			<span><?php esc_html_e( 'Add Image', 'pixtypes' ); ?></span></div>
		<span class="clear_gallery"><?php esc_html_e( 'Clear', 'pixtypes' ); ?></span>
	</a>
</div>
