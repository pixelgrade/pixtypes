<?php defined('ABSPATH') or die;
	/* @var PixtypesFormField $field */
	/* @var PixtypesForm $form */
	/* @var mixed $default */
	/* @var string $name */
	/* @var string $idname */
	/* @var string $label */
	/* @var string $desc */
	/* @var string $rendering */
?>

<tr valign="top">
	<th scope="row">
		<?php echo esc_html( $label ) ?>
	</th>
	<td>
		<fieldset>

			<legend class="screen-reader-text">
				<span><?php echo esc_html( $label ) ?></span>
			</legend>

			<?php foreach ($field->getmeta('options', array()) as $fieldname => $conf): ?>
				<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Nested field renderer escapes its own controls. ?>
				<?php echo $form->field($fieldname, $conf)->render() ?>
				<br/>
			<?php endforeach; ?>

			<?php if ($field->hasmeta('note')): ?>
				<small>
					<em>(<?php echo esc_html( $field->getmeta('note') ) ?>)</em>
				</small>
			<?php endif; ?>

		</fieldset>
	</td>
</tr>
