=== PixTypes ===
Contributors: pixelgrade, babbardel, vlad.olaru, razvanonofrei
Tags: custom, post-types, metadata, builder, gallery
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Theme-driven post types, taxonomies &amp; custom fields.

== Description ==

With [PixTypes](https://github.com/pixelgrade/pixtypes) you can allow your theme to define what custom post types or meta-boxes should be active when your theme is up

Note: This plugin is addressed to developers, it doesn't do nothing if it isn't [properly configured](https://github.com/pixelgrade/pixtypes#pixytpes_config).

== Installation ==

1. First you will need to configure your theme to [define PixTypes settings](https://github.com/pixelgrade/pixtypes#pixytpes_config)
2. Install PixTypes either via the WordPress.org plugin directory, or by uploading the files to your `/wp-content/plugins/` directory
3. After activating PixTypes all your custom post-types should be visible now.

== Changelog ==

= 2.0.2 =
* Declared compatibility with WordPress 7.1.

= 2.0.1 =
* Compatibility: Confirmed compatibility with WordPress 7.0.
* Compatibility: Hardened entity registration for invalid or unprefixed theme config keys.
* Compatibility: Updated metabox taxonomy term queries to the modern WordPress API format.
* Security: Improved request input handling in metabox save and AJAX flows.

= 2.0.0 =
* Security: Fixed Stored XSS vulnerability in HTML attribute rendering (HTMLTag class).
* Security: Fixed Reflected XSS via field_id parameter in oEmbed handler.
* Security: Fixed XSS via cmb_send_label using proper JS escaping (wp_json_encode).
* Security: Added nonce verification and capability checks to gallery AJAX preview handler.
* Security: Added nonce verification and capability checks to playlist AJAX preview handler.
* Security: Added capability check (manage_options) to theme settings cleanup AJAX handler.
* Security: Removed URL-controllable debug mode; now tied to WP_DEBUG constant.
* Security: Added output escaping throughout admin views and form templates.
* Security: Restricted POST input processing to expected fields only.
* Security: Sanitized all $_GET/$_POST/$_REQUEST superglobal usage with appropriate functions.
* Security: Updated nonce action strings to use specific identifiers.
* Improvement: Prefixed all global functions with pixtypes_ to prevent namespace collisions.
* Improvement: Removed deprecated &$this reference patterns for PHP 8 compatibility.
* Improvement: Updated minimum requirements to WordPress 6.0 and PHP 7.4.
* Improvement: Replaced EXT constant with PIXTYPES_EXT to avoid conflicts.

= 1.4.16 =
* XSS Security fix.

= 1.4.15 =
* CSRF Security fix.

= 1.4.14 =
* Improve compatibility with WordPress 5.7.

= 1.4.13 =
* Fixed a bug where, on some themes, metaboxes would still not appear when Gutenberg editor was active.

= 1.4.12 =
* Fixed a bug where metaboxes wouldn't appear when Gutenberg editor was active.
* Code optimization.

= 1.4.11 =
* We did several compatibility checks with the latest WordPress releases, so that everything will be working as smoothly as always.

= 1.4.10 =
* Fixed a bug related to not being able to empty file/image fields.

= 1.4.9 =
* Workflow to configure metaboxes dynamically rather than through the database.

= 1.4.8 =
* Cleanup and refactoring.
* Allow for field validation functions independent of CMB.

= 1.4.7 =
* Small improvements to the metabox system.
* Fixed Color Picker style.

= 1.4.6 =
* Fixed HTTPS WP admin issue with regards to assets.

= 1.4.5 =
* Added advanced show_on behaviour and filtering.

= 1.4.4 =
* Added a new image field type

= 1.4.3 =
* Fixed Builder on PHP 5.2
* Fixed Builder text block.Now it doesn't lose new lines on editor switch
* Fixed ColorPicker style in normal context
* Improved assets loading. Now we won't load styles on non-PixTypes pages.

= 1.4.2 =
* Fixed Builder visuals
* Safely sanitize builder output

= 1.4.1 =
* Fixed pix_builder on old configs.
* Fixed an issue with WPJM Extended Location
* Fixed new block ids in pix_builder

= 1.4.0 =
* Improved all the fields Visuals and styles.
* Improved the pix_builder field, now will save values in the content instead of its own meta.And the editor is better now.
* Added a positioning UI for the builder blocks.
* Fixed the defaults for the textarea fields.
* Fixed the defaults for colorpicker.
* Fixed small PHP warnings and notices.

= 1.3.5 =
Improved the multicheck field

= 1.3.3 =

* Added a Playlist field
* Improved translation strings
* Fixed Galleries Icons and Style
* Quit .mo/.po files for a general .pot one

= 1.3.2 =

* WordPress 4.3 compatibility
* Fixed Sticky buttons for the PixBuilder field

= 1.3.1 =

* Allow portfolio to be a jetpack compatible type
* Small fixes to the gallery field

= 1.2.10 =

* Show / Hide options bug fix

= 1.2.9 =

* Gmap pins added

= 1.2.6 =

* Builder field added
* Support for wp 4.0
* Small fixes

= 1.2.2 =

* Small fixes to metaboxes

= 1.2.1 =

* Github Updater slug fix
* And small fixes...

= 1.2.0 =

* Ajax Update
* Gallery Metabox works now even if there is no wp-editor on page
* And small fixes...

= 1.1.0 =

* Add admin panel
* Fixes

= 1.0.0 =
* Here we go
